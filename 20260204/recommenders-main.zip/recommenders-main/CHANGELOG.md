# Changelog

## [unreleased][unreleased]

## [0.7.6][2025-11-26]

### Changed

-   Add `tf-keras` (Keras 2) to `requirements.txt` and `pip_install.sh`.

## [0.7.5][2025-11-25]

### Changed

-   Updated release test script to use `export TF_USE_LEGACY_KERAS=1`. This is a
    no-op for the TFRS library but should allow us to push new releases to PyPI.

## [0.7.4][2025-11-04]

### Added

-   Add `tfrs.layers.feature_multiplexing.UnifiedEmbedding` and tutorial.

## [0.7.3][2023-02-02]

### Changed

-   The `Retrieval` task now accepts a list of factorized metrics instead of a
    single optional metric.

### Added

-   `tfrs.experimental.optimizers.ClippyAdagrad`: a new optimizer based on
    `tf.keras.optimizers.Adagrad` that is able to improve training stability.
-   `tfrs.metrics.FactorizedTopK` now accepts sample weights which are used to
    compute weighted top k metrics.

## [0.7.2][2022-09-28]

-   Improved support for using TPUEmbedding under parameter server strategy.

## [0.7.0][2022-07-07]

A number of changes to make factorized top-K metric computation more accurate
and less prone to user error.

### Changed

-   `tfrs.layers.embedding.TPUEmbedding` now supports input features with
    dynamic shape. `batch_size` argument is deprecated and no longer required.

-   `tfrs.layers.embedding.TPUEmbedding` now supports running on different
    versions of TPU.

-   Pinned TensorFlow to >= 2.9.0 which works with Scann 1.2.7.

-   `tfrs.tasks.Ranking.call` now accepts a `compute_batch_metrics` argument to
    allow switching off batch metric computation. Following this change,
    'compute_metrics'argument does not impact computation of batch metrics.

### Breaking changes

-   `tfrs.metrics.FactorizedTopK` requires the candidate ids for positive
    candidates to be supplied when using approximate top-K sources. Each top-K
    layer now has an `exact` method to broadcast its ability to return exact or
    approximate top-K results.
-   Removed `metrics` constructor parameter for `tfrs.metrics.FactorizedTopK`.
    `FactorizedTopK` only makes sense with top-k metrics, and this change
    enforces this.
-   Replaced the `k` constructor argument in `tfrs.metrics.FactorizedTopK` with
    `ks`: a list of `k` values at which to compute the top k metric.

### Changed

-   The `tfrs.metrics.FactorizedTopK` metric can now compute candidate-id based
    metrics when given the `true_candidate_ids` argument in its `call` method.

### Added

-   The `Retrieval` task now also accepts a `loss_metrics` argument.

## [0.6.0][2021-08-23]

### Changed

-   Pinned TensorFlow to >= 2.6.0, which works with Scann 1.2.3.

### Breaking changes

-   `TopK` layer indexing API changed. Indexing with datasets is now done via
    the `index_from_dataset` method. This change reduces the possibility of
    misaligning embeddings and candidate identifiers when indexing via
    indeterministic datasets.

## [0.5.2][2021-07-15]

### Fixed

-   Fixed error in default arguments to `tfrs.experimental.models.Ranking`
    (https://github.com/tensorflow/recommenders/issues/311).
-   Fix TPUEmbedding layer to use named parameters.

### Added

-   Added `batch_metrics` to `tfrs.tasks.Retrieval` for measuring how good the
    model is at picking out the true candidate for a query from other candidates
    in the batch.
-   Added `tfrs.experimental.layers.embedding.PartialTPUEmbedding` layer, which
    uses `tfrs.layers.embedding.TPUEmbedding` for large embedding lookups and
    `tf.keras.layers.Embedding` for smaller embedding lookups.

## [0.5.1][2021-05-14]

### Changed

-   Supplying incompatibly-shaped candidates and identifiers inputs to
    `factorized_top_k` layers will now raise (to prevent issues similar to
    https://github.com/tensorflow/recommenders/issues/286).

## [0.5.0][2021-05-06]

### Changed

-   Fixed the bug in `tfrs.layers.loss.SamplingProbablityCorrection` that logits
    should subtract the log of item probability.
-   `tfrs.experimental.optimizers.CompositeOptimizer`: an optimizer that
    composes multiple individual optimizers which can be applied to different
    subsets of the model's variables.
-   `tfrs.layers.dcn.Cross` and `DotInteraction` layers have been moved to
    `tfrs.layers.feature_interaction` package.

### Added

-   `tfrs.experimental.models.Ranking`, an experimental pre-built model for
    ranking tasks. Can be used as DLRM like model with Dot Product feature
    interaction or DCN like model with Cross layer.

## [0.4.0][2021-01-20]

### Added

-   `TopK` layers now come with a `query_with_exclusions` method, allowing
    certain candidates to be excluded from top-k retrieval.
-   `TPUEmbedding` Keras layer for accelerating embedding lookups for large
    tables with TPU.

### Changed

-   `factorized_top_k.Streaming` layer now accepts a query model, like other
    `factorized_top_k` layers.

-   Updated ScaNN to 1.2.0, which requires TensorFlow 2.4.x. When not using
    ScaNN, any TF >= 2.3 is still supported.

## [0.3.2][2020-12-22]

### Changed

-   Pinned TensorFlow to >= 2.3 when ScaNN is not being installed. When ScaNN is
    being installed, we pin on >= 2.3, < 2.4. This allows users to use TFRS on
    TF 2.4 when they are not using ScaNN.

## [0.3.1][2020-12-22]

### Changed

-   Pinned TensorFlow to 2.3.x and ScaNN to 1.1.1 to ensure TF and ScaNN
    versions are in lockstep.

## [0.3.0][2020-11-18]

### Added

-   Deep cross networks: efficient ways of learning feature interactions.
-   ScaNN integration: efficient approximate maximum inner product search for
    fast retrieval.

## [0.2.0][2020-10-15]

### Added

-   `tfrs.tasks.Ranking.call` now accepts a `compute_metrics` argument to allow
    switching off metric computation.
-   `tfrs.tasks.Ranking` now accepts label and prediction metrics.
-   Add metrics setter/getters on `tfrs.tasks.Retrieval`.

### Breaking changes

-   Corpus retrieval metrics and layers have been reworked.

    `tfrs.layers.corpus.DatasetTopk` has been removed,
    `tfrs.layers.corpus.DatasetIndexedTopK` renamed to
    `tfrs.layers.factorized_top_k.Streaming`, `tfrs.layers.ann.BruteForce`
    renamed to `tfrs.layers.factorized_top_k.BruteForce`. All top-k retrieval
    layers (`BruteForce`, `Streaming`) now follow a common interface.

### Changed

-   `Dataset` parallelism enabled by default in `DatasetTopK` and
    `DatasetIndexedTopK` layers, bringing over 2x speed-ups to evaluations
    workloads.
-   `evaluate_metrics` argument to `tfrs.tasks.Retrieval.call` renamed to
    `compute_metrics`.
